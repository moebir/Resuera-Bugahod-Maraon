﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace resuera_registration_form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            string name = NameTxtBox.Text;
            string gender = GenderTxtBox.Text;
            string mobile = MobileTxtBox.Text;
            string email = EmailTxtBox.Text;
            string address = AddressTxtBox.Text;
            string course = CourseTxtBox.Text;

            if (name == "" || gender == "" || mobile == "" || email == "" || address == "" || course == "")
            {
                MessageBox.Show("Fill in empty box");
                return;
            }

            string connString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\MARL DENZELL SILVA\\source\\repos\\resuera-registration-form\\students.mdf\";Integrated Security=True;Connect Timeout=30";
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string sql = "INSERT INTO Students (Name, Gender, Mobile, Email, Address, Course) VALUES (@name, @gender, @mobile, @email, @address, @course)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = name;
                cmd.Parameters.Add("@gender", SqlDbType.VarChar, 255).Value = gender;
                cmd.Parameters.Add("@mobile", SqlDbType.VarChar, 255).Value = mobile;
                cmd.Parameters.Add("@email", SqlDbType.VarChar, 255).Value = email;
                cmd.Parameters.Add("@address", SqlDbType.VarChar, 255).Value = address;
                cmd.Parameters.Add("@course", SqlDbType.VarChar, 255).Value = course;

                //Check database connection and execute
                try
                {
                    conn.Open();
                    Int32 rowsAffected = cmd.ExecuteNonQuery();
                    MessageBox.Show("Registered successfully.");
                    NameTxtBox.Clear();
                    GenderTxtBox.Clear();
                    MobileTxtBox.Clear();
                    EmailTxtBox.Clear();
                    AddressTxtBox.Clear();
                    CourseTxtBox.Clear();
                    conn.Close();
                    //Console.WriteLine("RowsAffected: " + rowsAffected);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Something went wrong");
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
